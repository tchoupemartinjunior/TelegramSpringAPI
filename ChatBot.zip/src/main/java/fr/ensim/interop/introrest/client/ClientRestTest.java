package fr.ensim.interop.introrest.client;

public class ClientRestTest {
	
	public static void main(String[] args) {
	
		//Vous pouvez faire des tests d'appels d'API ici
	}
}
