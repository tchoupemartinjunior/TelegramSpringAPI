package fr.ensim.interop.introrest.model.telegram.model;

public class GeoCodeResponse {
    
    

}
